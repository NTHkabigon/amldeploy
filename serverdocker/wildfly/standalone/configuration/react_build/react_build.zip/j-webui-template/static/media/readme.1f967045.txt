getConfigTemplate(){
    return {
          dataFull:
    {
        isCheck:false,          // nếu được check thì truyền là true
        
    }
}
}

<UTableColumnCheckbox {...this.getConfigTemplate()}></UTableColumnCheckbox>


