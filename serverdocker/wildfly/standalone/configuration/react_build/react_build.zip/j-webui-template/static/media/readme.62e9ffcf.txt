    widget:
        {
            type: "active", // status: active, danger, default, success, warning, purple 
            title: "Active", // title của status
        }