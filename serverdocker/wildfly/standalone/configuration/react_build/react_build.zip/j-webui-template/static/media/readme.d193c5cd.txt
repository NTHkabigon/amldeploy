Khu vực làm việc của website
Ở đây có các hàm mở để gọi và bị gọi cập nhập các thành phần bên trong
data:
    dataFull:
    {
       

            contentItem: [

                {
                    code:"",            // code là tên của các components
                    codeHidden:""       // mã định danh của component
                    dataFull:[          // dataFull của các components

                    ]
                },
                ....
            ]
    }