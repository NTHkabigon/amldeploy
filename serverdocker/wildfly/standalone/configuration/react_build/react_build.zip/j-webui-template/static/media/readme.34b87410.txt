 stateData: {
        form: {
          config: {
            default: {
              title: "Foreign exchange rate", //title của uForm
              title_sub: "",
            },
          },
          cmd: { visibility: "" }, // "none" hoặc "" là ẩn hiện form
        },
        save_rate: {
          dataFull: {
            config: {
              default: {
                title: "Save",
                type: "submit",
                class: "",
                icon: "save",
              },
            },
          },
          abs_Click: this.abs_Click,
        },
        modify_rate: {
          dataFull: {
            config: {
              default: {
                title: "Modify",
                type: "",
                class: "",
                icon: "search",
              },
            },
          },
          abs_Click: this.abs_Click,
        },
        dateTimeUpdate: {
          title: "26/06/2020",
        },
        tab: [
          {
            title: "Base currency rate",
            id: "1",
          },
          {
            title: "Local currency rate",
            id: "2",
          },
        ],
        table_rate_header: {
          Header: {
            data: [
              {
                title: "Currency code",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
              {
                title: "Short ID",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
              {
                title: "BK rate",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
              {
                title: "TB rate",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
              {
                title: "TA rate",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
              {
                title: "CA rate",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
              {
                title: "CB rate",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
              {
                title: "CS rate",
                config: {
                  //nếu có set width thì truyền vào
                  width: "",
                  isFrozen: false,
                },
              },
            ],
            config: {
              mode: {
                hasSearch: false,
              },
            },
          },
        },
        table_rate_data: {
          data: [
            {
              all_column: [
                {
                  value: "vi",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "1.00000000000",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
              ],
            },
            {
              all_column: [
                {
                  value: "vi",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "1.00000000000",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
              ],
            },
            {
              all_column: [
                {
                  value: "vi",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "1.00000000000",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
                {
                  value: "en",
                  isUpdate: false,
                  dataItem: { abc: "nội dung của dev gửi vào tuỳ ý" },
                  abs_Change: this.table_input_change,
                },
              ],
            },
          ],
        },
      },