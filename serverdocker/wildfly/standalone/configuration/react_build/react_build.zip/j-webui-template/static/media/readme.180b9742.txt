nếu sử dụng uTableColumnCheckBox thì khi click vào checkbox truyền vào uTableBodyRow với isCheck tương ứng với cú pháp
<uTableBodyRow isCheck={true/false}></uTableBodyRow>