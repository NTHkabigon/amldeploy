data:
  stateData: {
        title: "Delete selected files?",
        content: "Are you sure you want to delete selected files?",
        abs_Click: .....
        listButton: [
          {
            dataFull:
            {
              config: {
                default: {
                  title: "Add new",
                  type: "",
                  class: ""

                },

              },
            },
            abs_Click: this.abs_Click
          },
          {
            dataFull:
            {
              config: {
                default: {
                  title: "Add new",
                  type: "",
                  class: ""

                },

              },
            },
            abs_Click: this.abs_Click
          },
          {
            dataFull:
            {
              config: {
                default: {
                  title: "Add new",
                  type: "primary",
                  class: ""

                },

              },
            },
            abs_Click: this.abs_Click
          },

        ]
      },