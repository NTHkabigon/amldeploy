<UView class = "col-md-6" dataFull: {
	config: {
		class:"",
		title:"",
		isBorder:false,
	}>test</UView>

class = col-md-6 // Số cột muốn hiển thị trên view