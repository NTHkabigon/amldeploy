hàm truyền ra:
    +abs_select(item) trả về item được chọn.
                - yêu cầu xử lý: từ item được chọn mở thêm tab mới.
